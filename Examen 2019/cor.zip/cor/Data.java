package cor;

public class Data {

	private String type;
	private int measurement;

	public Data(String type, int measurement) {
		this.type = type;
		this.measurement = measurement;
	}

	public String getType() {
		return type;
	}

	public int getMeasurement() {
		return measurement;
	}

	@Override
	public String toString() {
		return "Data [type=" + getType() + ",\n " + "measurement=" + getMeasurement() + "]";
	}
}
