package cor;

public class SmokeSensor implements Sensor {
	
	@Override
	public void notify(int measurement) {
		if(measurement==1)
			System.out.println("Notification reçue du capteur de fumée : Alerte feu !");
	}
}
