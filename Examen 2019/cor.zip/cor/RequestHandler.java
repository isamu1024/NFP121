package cor;

public interface RequestHandler {

public RequestHandler setNextRequestHandler(RequestHandler requestHandler);
        
public boolean process(Data data);
}
