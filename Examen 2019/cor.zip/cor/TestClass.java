package cor;

public class TestClass extends junit.framework.TestCase {
	
    public void testUnique() {
        Data tempData = new Data("Temperature",30);
        Data smokeData = new Data("smoke",1);
        Data motionData = new Data("Motion",1);
        Sensor tempSensor = new TempSensor();
        Sensor smokeSensor = new SmokeSensor();
        Sensor motionSensor = new MotionSensor();
        
        RequestHandler handler = new TempHandler(tempSensor);        
        handler.setNextRequestHandler(new SmokeHandler(smokeSensor)).setNextRequestHandler(new MotionHandler(motionSensor));
        
        assertTrue(handler.process(smokeData));
        assertTrue(handler.process(tempData));
        assertTrue(handler.process(motionData));
    }
}
