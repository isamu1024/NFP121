package cor;

public class TempHandler implements RequestHandler {

    private RequestHandler requestHandler;
    private Sensor sensor;

    public TempHandler(Sensor sensor) {
		this.sensor = sensor;
	}

	@Override
    public RequestHandler setNextRequestHandler(RequestHandler requestHandler) {
        this.requestHandler = requestHandler;
        return requestHandler;
    }

    @Override
    public boolean process(Data data) {
    	if(sensor instanceof TempSensor && data.getType().equalsIgnoreCase("temperature"))
    			sensor.notify(data.getMeasurement());
        return requestHandler == null ? true : requestHandler.process(data);
    }
}
