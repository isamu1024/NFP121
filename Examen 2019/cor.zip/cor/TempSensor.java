package cor;

public class TempSensor implements Sensor {
	
	@Override
	public void notify(int measurement) {
		if(measurement>25)
			System.out.println("Notification reçue du capteur de température : température trop élevée");
		else if (measurement<15)
			System.out.println("Notification reçue du capteur de température : température trop basse");
	}
}
