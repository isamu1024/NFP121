package cor;

public class MotionHandler implements RequestHandler {

	private RequestHandler requestHandler;
    private Sensor sensor;

    public MotionHandler(Sensor sensor) {
		this.sensor = sensor;
	}

	@Override
    public RequestHandler setNextRequestHandler(RequestHandler requestHandler) {
        this.requestHandler = requestHandler;
        return requestHandler;
    }

    @Override
    public boolean process(Data data) {
    	if(sensor instanceof MotionSensor && data.getType().equalsIgnoreCase("motion"))
    			sensor.notify(data.getMeasurement());
        return requestHandler == null ? true : requestHandler.process(data);
    }
    
}
