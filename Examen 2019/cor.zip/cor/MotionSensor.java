package cor;

public class MotionSensor implements Sensor {
	
	@Override
	public void notify(int measurement) {
		if(measurement==1)
			System.out.println("Notification reçue du détecteur de mouvement : Alerte intrusion !");
	}
}
