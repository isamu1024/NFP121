package cor;

public interface Sensor {
	
	public void notify(int measurement);

}
