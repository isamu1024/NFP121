package composite;

import java.util.ArrayList;
import java.util.List;

public class Responsable implements EnseignantI {

	private String nomEnseignant;
	private String nomEntite;
	private List<EnseignantI> collaborateurs;

	Responsable(String nomEnseignant, String nomEntite) {
		this.nomEnseignant = nomEnseignant;
		this.nomEntite = nomEntite;
		collaborateurs = new ArrayList<EnseignantI>();
	}

	public void Add(EnseignantI Enseignant) {
		collaborateurs.add(Enseignant);
	}

	public void Remove(EnseignantI Enseignant) {
		collaborateurs.remove(Enseignant);
	}

	public List<EnseignantI> getCollaborateurs() {
		return collaborateurs;
	}

	@Override
	public String getDetails() {
		String str = nomEnseignant + " est responsable " + nomEntite;
		for (EnseignantI ens : this.getCollaborateurs()) {
			str += "\n\t" + ens.getDetails();
		}
		return str;
	}
}
