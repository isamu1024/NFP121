package composite;

public class TestClass  extends junit.framework.TestCase {

	 public void testUnique() {
		Responsable directrice = new Responsable("Mme. Dupond", "Université");
		Responsable math = new Responsable("M. Durand", "Département Mathématiques");
		Responsable info = new Responsable("M. Duval", "Département Informatique");

		EnseignantI ensMath1 = new Enseignant("Mme Cerise");
		EnseignantI ensMath2 = new Enseignant("M. Prune");
		EnseignantI ensInfo1 = new Enseignant("Mlle Framboise");
		EnseignantI ensInfo2 = new Enseignant("M. Patate");
		EnseignantI ensInfo3 = new Enseignant("Mme Orange ");

		directrice.Add(math);
		directrice.Add(info);
		math.Add(ensMath1);
		math.Add(ensMath2);
		info.Add(ensInfo1);
		info.Add(ensInfo2);
		info.Add(ensInfo3);

		assertTrue(directrice.getCollaborateurs().size()==2);
		assertTrue(((Responsable)directrice.getCollaborateurs().get(1)).getCollaborateurs().size()==3);
		assertTrue(math.getCollaborateurs().size()==2);
		assertTrue(info.getCollaborateurs().size()==3);
		
		System.out.println("L'université a la structure suivante :");
		System.out.println(directrice.getDetails());

		info.Remove(ensInfo2);
		System.out.println("\nAprès le départ de ensInfo2- le départment d'informatique a les enseignants suivants :");
		System.out.println(info.getDetails());
	}
}
