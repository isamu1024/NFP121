package composite;

public class Enseignant implements EnseignantI{

	private String nomEnseignant;

	Enseignant(String nomEnseignant)	{
		this.nomEnseignant = nomEnseignant;
	}

	@Override
	public String getDetails() {
		return ("\tenseignant : "+nomEnseignant);
	}
}
