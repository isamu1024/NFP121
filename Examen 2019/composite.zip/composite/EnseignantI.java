package composite;

public interface EnseignantI {

	public String getDetails();
}
