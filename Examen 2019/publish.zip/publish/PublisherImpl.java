package publish;

/** Implémentation de l'envoie un message au service PubSub */
public class PublisherImpl implements PublisherI {

		public void publish(Message message, PubSubService pubSubService) {		
			pubSubService.addMessageToQueue(message);
		}
}
