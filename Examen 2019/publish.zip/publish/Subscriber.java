package publish;

import java.util.ArrayList;
import java.util.List;

/**
 * La classe abstraite Subscriber définit un attribut et quelques méthodes
 * concrètes. 3 méthodes abstraites restent à écrire dans l'implémentation.
 */
public abstract class Subscriber {
	/**
	 * Liste des messages reçus par le subscriber (l'abonné).
	 */
	private List<Message> subscriberMessages = new ArrayList<Message>();

	/**
	 * Ajoute / inscrit un abonné pour un sujet auprès du médiateur (le service
	 * PubSub).
	 * 
	 * @param topic, le sujet pour lequel désabonner le subscriber
	 * @param pubSubService, le médiateur
	 */
	public abstract void addSubscriber(String topic, PubSubService pubSubService);

	/**
	 * Désabonne le subscriber auprès du médiateur pour un sujet donné
	 * 
	 * @param topic
	 * @param pubSubService
	 */
	public abstract void unSubscribe(String topic, PubSubService pubSubService);

	/**
	 * demande les messages relatifs à un topic
	 * 
	 * @param topic
	 * @param pubSubService
	 */
	public abstract void getMessagesForSubscriberOfTopic(String topic, PubSubService pubSubService);

	/**
	 * Affiche les messages reçus par le subscriber (l'abonné)
	 */
	public void displayMessages() {
		for (Message message : subscriberMessages) {
			System.out.println("Message Topic -> " + message.getTopic() + " : " + message.getPayload());
		}
	}
	
	/**
	 * Vide la liste de messages
	 */
	public void emptyMessageList() {
		subscriberMessages.removeAll(getSubscriberMessages());
	}

	/**
	 * getter, retourne la liste des messages reçus par l'abonné
	 * 
	 * @return subscriberMessages
	 */
	public List<Message> getSubscriberMessages() {
		return subscriberMessages;
	}

	/**
	 * setter, affecte une liste de message à l'abonné
	 * 
	 * @param subscriberMessages
	 */
	public void setSubscriberMessages(List<Message> subscriberMessages) {
		this.subscriberMessages = subscriberMessages;
	}
}