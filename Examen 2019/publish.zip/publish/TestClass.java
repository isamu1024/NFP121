package publish;

public class TestClass extends junit.framework.TestCase {
	
	private PublisherI publisher = new PublisherImpl();

	private Subscriber javaSubscriber = new SubscriberImpl();
	private Subscriber allLanguagesSubscriber = new SubscriberImpl();
	private Subscriber pythonSubscriber = new SubscriberImpl();

	private PubSubService pubSubService = new PubSubService();
	
	public void testUnique() {

		Message javaMsg1 = new Message("Java", "Core Java Concepts");
		Message javaMsg2 = new Message("Java", "Spring Boot");
		Message javaMsg3 = new Message("Java", "JPA & Hibernate");
		Message pythonMsg1 = new Message("Python", "Easy and Powerful programming language");
		Message pythonMsg2 = new Message("Python", "Advanced Python message");
		
		publisher.publish(javaMsg1, pubSubService);		
		publisher.publish(javaMsg2, pubSubService);		
		publisher.publish(javaMsg3, pubSubService);	
		publisher.publish(pythonMsg1, pubSubService);
		publisher.publish(pythonMsg2, pubSubService);

		javaSubscriber.addSubscriber("Java", pubSubService);				
		pythonSubscriber.addSubscriber("Python", pubSubService); 		
		allLanguagesSubscriber.addSubscriber("Java", pubSubService); 		
		allLanguagesSubscriber.addSubscriber("Python", pubSubService);
		
		assertTrue("javaSubscriber n'est pas vide ?",javaSubscriber.getSubscriberMessages().isEmpty());
		assertTrue("pythonSubscriber n'est pas vide ?",pythonSubscriber.getSubscriberMessages().isEmpty());
		assertTrue("allLanguagesSubscriber n'est pas vide ?",allLanguagesSubscriber.getSubscriberMessages().isEmpty());

		pubSubService.broadcast();
		
		assertTrue("javaSubscriber  n'a pas reçu exactement 3 messages ?",javaSubscriber.getSubscriberMessages().size()==3);
		assertTrue("pythonSubscriber n'a pas reçu exactement 2 messages ?",pythonSubscriber.getSubscriberMessages().size()==2);
		assertTrue("allLanguagesSubscriber n'a pas reçu exactement 5 messages ?",allLanguagesSubscriber.getSubscriberMessages().size()==5);

		System.out.println("Messages of Java Subscriber are: ");
		javaSubscriber.displayMessages();
		System.out.println("\nMessages of Python Subscriber are: ");
		pythonSubscriber.displayMessages();
		System.out.println("\nMessages of All Languages Subscriber are: ");
		allLanguagesSubscriber.displayMessages();
		
		javaSubscriber.emptyMessageList();
		assertTrue("javaSubscriber n'est pas vide ?",javaSubscriber.getSubscriberMessages().isEmpty());
		
		pythonSubscriber.unSubscribe("Python", pubSubService);
		System.out.println("\npython Subscriber cancelled its subscription");

		System.out.println("\nPublishing 2 more Java Messages...");
		Message javaMsg4 = new Message("Java", "JSP and Servlets");
		Message javaMsg5 = new Message("Java", "JSF framework");

		publisher.publish(javaMsg4, pubSubService);
		publisher.publish(javaMsg5, pubSubService);

		javaSubscriber.getMessagesForSubscriberOfTopic("Java", pubSubService);
		assertTrue("javaSubscriber  n'a pas reçu exactement 2 messages ?",javaSubscriber.getSubscriberMessages().size()==2);
		System.out.println("\nMessages of Java Subscriber now are: ");
		javaSubscriber.displayMessages();
		
		System.out.println("\nPublishing 1 more Python Message...");
		Message pythonMsg3 = new Message("Python", "Django: QuickStart Guide");

		publisher.publish(pythonMsg3, pubSubService);
		pubSubService.broadcast();
		
		assertTrue("pythonSubscriber n'a pas reçu exactement 2 messages ?",pythonSubscriber.getSubscriberMessages().size()==2);
		assertTrue("allLanguagesSubscriber n'a pas reçu exactement 6 messages ?",allLanguagesSubscriber.getSubscriberMessages().size()==6);

		System.out.println("\nMessages of Python Subscriber now are: ");
		pythonSubscriber.displayMessages();
		
		System.out.println("\nMessages of all Languages Subscriber now are: ");
		allLanguagesSubscriber.displayMessages();
	}
}
