package publish;

/**
 * L'interface PublisherI définit la méthode abstraite publish () qui envoie un message au service PubSub,
 * càd au médiateur
 *
 */
public interface PublisherI {
	/**
	 * Publie le message auprès du médiateur
	 * @param message			Le message
	 * @param pubSubService		le médiateur
	 *
	 */
	public void publish(Message message, PubSubService pubSubService);
}
