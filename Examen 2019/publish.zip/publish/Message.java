package publish; 

public class Message {	
	
	/** le sujet du message auquel peut s'abonner un subscriber	 */
	private String topic;
	/** Le contenu du message */
	private String payload;
	
	/**
	 * Le constructeur
	 * @param topic
	 * @param payload
	 */
	public Message(String topic, String payload) {
		this.topic = topic;
		this.payload = payload;
	}
	/**les getters et setters */
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}
}
