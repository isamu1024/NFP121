package iterator;


public abstract class Maillon<E> {
    // variables d'instance - remplacez l'exemple qui suit par le v�tre
    private Maillon<E> successeur;

 
    public Maillon(Maillon<E> successeur){
       this.successeur = successeur;
    }

  
    public boolean execute(E e){
      if(successeur!=null)
        return successeur.execute(e);
      else
        return false;
    }
}
