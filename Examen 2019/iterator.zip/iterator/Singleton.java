package iterator;


public final class Singleton{
    // variables d'instance - remplacez l'exemple qui suit par le v�tre
    private static Singleton instance = null;

    private Singleton(){
       
    }

 
    public static Singleton getInstance(){
        synchronized(if(instance==null) instance = new Singleton();
        return instance;
    }
}
