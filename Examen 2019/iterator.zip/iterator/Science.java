package iterator;

import java.util.ArrayList;
import java.util.List;

/** La classe Science a un attribut de type List*/
public class Science implements MatiereI {

	private List<String> matieres;

	public Science(){
		matieres = new ArrayList<String>();
		matieres.add("Maths");
		matieres.add("Informatique");
		matieres.add("Physique");
	}       
	
	@Override
	public IteratorI<String> CreateIterator() 	{
		return new ScienceIterator(matieres);
	}
}
