package iterator;

import java.util.*;

public class Bean{
    // variables d'instance - remplacez l'exemple qui suit par le v�tre
    private int x;
    private List<Integer> list;

    public Bean(){
        // initialisation des variables d'instance
        x = 0;
    }

    public void setX(int x){
        this.x = x;
        System.out.println("x: " + x);
    }
    
    public void setList(List<Integer> list){
        this.list = list;
        System.out.println("list: " + list);
    }
 
}
