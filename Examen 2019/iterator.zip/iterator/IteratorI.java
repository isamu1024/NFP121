package iterator;

/**
 * Un itérateur est utilisé pour retourner les éléments une seule fois, en
 * séquence, par appels successifs à la méthode next.
 */
public interface IteratorI <E>{

	/** Ramène l'iterateur sur le 1er élément de la structure */
	void first();

	/**
	 * Retourne l'élément suivant de la structure
	 * @return E
	 */
	public E next();

	/**
	 * Teste s'il reste des éléments dans la structure
	 * @return boolean
	 */
	public boolean hasNext();

	/**
	 * Retourne l'élément courant de la structure parcourue
	 * @return E
	 */
	public E currentItem();
}
