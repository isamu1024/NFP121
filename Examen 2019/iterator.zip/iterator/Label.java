package iterator;


public class Label extends Component{

   public  String interpreter(){
       return "Label";
    }
}
