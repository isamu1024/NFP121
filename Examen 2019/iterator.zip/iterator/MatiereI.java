package iterator;

/** L'interface pour les matières scolaire contient une méthode unique */
public interface MatiereI {
	
	/**
	 * Crée et retroune un itérateur pour la classe
	 * @return IteratorI
	 */
	public IteratorI<String> CreateIterator();
}
