package iterator;

public abstract class Component{
   
    public abstract String interpreter();
    
    public void add(Component c){
        throw new IllegalArgumentException();
    }
}
