package iterator;

/**
 * Une implémentation de Iterator pour un tableau de String
 */
public class LiteratureIterator implements IteratorI<String> {

		private String[] matieres;
		private int position;
		
		public LiteratureIterator(String[] matieres)	{
			this.matieres = matieres;
			position = 0;
		}
		
		@Override
		public void first()	{
			position = 0;
		}
		
		@Override
		public String next(){
			return matieres[position++];
		}
		
		@Override
		public boolean hasNext()	{
			return position < matieres.length;
		}
		
		@Override
		public String currentItem()	{
			return matieres[position];
		}
	}
