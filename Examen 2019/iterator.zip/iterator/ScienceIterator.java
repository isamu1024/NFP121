package iterator;

import java.util.List;

/**
 * Une implémentation de Itarator pour une List de String
 */
public class ScienceIterator implements IteratorI<String> {

	private List<String> matieres;
	private int position;

	public ScienceIterator(List<String> matieres)	{
		this.matieres = matieres;
		position = 0;
	}   
	
	@Override
	public void first()	{
		position = 0;
	}
	
	@Override
	public String next() {
		return matieres.get(position++);
	}
	
	@Override
	public boolean hasNext() {
		return position < matieres.size();
	}
	
	@Override
	public String currentItem()	{
		return matieres.get(position);
	}       
}
