package iterator;



public class Filtre extends Maillon<Integer>{
    private int seuil;
    
    public Filtre(Maillon<Integer> m, int seuil){
        super(m);
        this.seuil= seuil;
    }
  public boolean execute(Integer e){
    if(e<seuil){
      System.out.println( e + " inferieur au seuil " + seuil );
      return true;
    }else 
      return super.execute(e);
      
    }
}
