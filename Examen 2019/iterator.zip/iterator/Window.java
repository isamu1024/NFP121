package iterator;

import java.util.*;

public class Window extends Component{
    // variables d'instance - remplacez l'exemple qui suit par le v�tre
    private List<Component> list;
   public Window(){
      this.list = new ArrayList<>();
    }

  
    public String interpreter(){
       String res = "";
       for(Component c : list){
           res = res + c.interpreter();
        }
        return res;
    }
    
       public void add(Component c){
           list.add(c);
        }
}
