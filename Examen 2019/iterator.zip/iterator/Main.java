package iterator;

import java.lang.reflect.*;

public class Main{
  
 
    public static void test(String nomDeClasse) throws Exception{
        
        Class<?> cl = Class.forName(nomDeClasse); 
        Object object = cl.newInstance(); 
        Method m = cl.getMethod("setX", int.class);
        m.invoke(object, 33);
        
        Class<?> cl2 = Class.forName("java.util.ArrayList"); 
        Object object2 = cl2.newInstance();
        Method m3 = cl2.getMethod("add", Object.class);
        m3.invoke(object2, new String("bonne r�vision pourle mardi 4 f�vrier"));
        
        Method m2 = cl.getMethod("setList", java.util.List.class);
        m2.invoke(object, object2);
        
        // Component c = new Window();
        // c.add(new Label());
        
        // Component c1 = new Window();
         // c1.add(new Label());
         
       // c.add(c1);
       // String s = c.interpreter();
        
       // Maillon<Integer> trace = new Trace<>(null);
       // trace.execute(100);
       // trace = new Trace<>(new Filtre( new Filtre(null,300),100));
       // trace.execute(100);
       
       // trace.execute(80);
       // trace.execute(200);
        // trace.execute(400);
    }
}
