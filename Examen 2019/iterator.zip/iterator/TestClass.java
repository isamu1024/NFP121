package iterator;

public class TestClass extends junit.framework.TestCase {
	
	public void testUnique() 	{
		MatiereI matSc = new Science();
		MatiereI matLit = new Literature();
		int count = 1;
		
		IteratorI<String> scIterator = matSc.CreateIterator();
		while (scIterator.hasNext())	{
			String sc ;
			assertTrue(scIterator.currentItem()== (sc= scIterator.next()));
			switch (count) {
			case 1 : assertTrue(sc.equals("Maths"));
					assertTrue(scIterator.currentItem().equals("Informatique"));
					break;	
			case 2 : assertTrue(sc.equals("Informatique"));
					assertTrue(scIterator.currentItem().equals("Physique"));
					break;
			case 3 : assertTrue(sc.equals("Physique"));
					break;
			}
			count++;
		}
		count=1;		
		IteratorI<String> litIterator = matLit.CreateIterator();
		while (litIterator.hasNext())	{
			String lit;
			assertTrue(litIterator.currentItem()== (lit= litIterator.next()));
			switch (count) {
			case 1 : assertTrue(lit.equals("Anglaise"));
					assertTrue(litIterator.currentItem().equals("Française"));
					break;
			case 2 : assertTrue(lit.equals("Française"));
					break;
			}
			count++;
		}          
	}
}
