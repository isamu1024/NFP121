package iterator;

/** La classe Literature a un attribut de type tableau*/
public class Literature implements MatiereI {

	private String[] matieres;

	public Literature(){           
		matieres = new String[2];
		matieres[0] = "Anglaise";
		matieres[1] = "Française" ;
	}

	@Override
	public IteratorI<String> CreateIterator() {
		return new LiteratureIterator(matieres);
	}
}
