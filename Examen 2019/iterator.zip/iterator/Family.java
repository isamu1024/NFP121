package iterator;
import java.util.*;

class Family<E> implements Iterable<E> {
    private final Set<E> elements;
  
    public Family(Set<E> elements) {
        this.elements = Set.copyOf(elements);
    }
    
    @Override
    public Iterator<E> iterator() {
        return new InterIterator(elements.iterator());
    }
    
    private static class InterIterator<E> implements Iterator<E>{
        private Iterator<E> iterator;
        InterIterator(Iterator<E> iterator){
            this.iterator = iterator;
        }
        public boolean hasNext(){return iterator.hasNext();}
        public E next(){return iterator.next();}
        public void remove(){new RuntimeException("remove prohibited");}
    }
}