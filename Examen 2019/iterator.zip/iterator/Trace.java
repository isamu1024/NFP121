package iterator;



public class Trace<E> extends Maillon<E>{

    public Trace(Maillon<E> m){
        super(m);
    }
  public boolean execute(E e){
    System.out.println("e: " + e );
    return super.execute(e);
    }
}
